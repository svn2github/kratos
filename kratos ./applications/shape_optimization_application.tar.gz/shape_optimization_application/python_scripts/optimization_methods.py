##################################################################################################

from __future__ import print_function, absolute_import, division #makes KratosMultiphysics backward compatible with python 2.6 and 2.7
# importing the Kratos Library
from KratosMultiphysics import *
from KratosMultiphysics.ShapeOptimizationApplication import *
# check that KratosMultiphysics was imported in the main script
CheckForPreviousImport()

# For GID output
from gid_output import GiDOutput

# Further necessary imports
import csv
import numpy as np
import time

##################################################################################################

class VertexMorphingMethod:

    # ********************************************************************************************
    def __init__(self,opt_model_part,config,J,C):

        # For GID output
        self.gid_io = GiDOutput(config.design_surface_name,
                                config.VolumeOutput,
                                config.GiDPostMode,
                                config.GiDMultiFileFlag,
                                config.GiDWriteMeshFlag,
                                config.GiDWriteConditionsFlag)


        # Add variables needed for shape optimization
        opt_model_part.AddNodalSolutionStepVariable(NORMALIZED_SURFACE_NORMAL)
        opt_model_part.AddNodalSolutionStepVariable(OBJECTIVE_SENSITIVITY)
        opt_model_part.AddNodalSolutionStepVariable(CONSTRAINT_SENSITIVITY) 
        opt_model_part.AddNodalSolutionStepVariable(SHAPE_UPDATE) 
        opt_model_part.AddNodalSolutionStepVariable(SHAPE_CHANGE_ABSOLUTE) 
        
        # Read and print model part (design surface)
        buffer_size = 1
        model_part_io = ModelPartIO(config.design_surface_name)
        model_part_io.ReadModelPart(opt_model_part)
        opt_model_part.SetBufferSize(buffer_size)
        print("\nThe following design surface was defined:\n\n",opt_model_part)

        # Define configurations
        self.config = config

        # Define objective functions
        # Format: J = { objective_id:{"func":xxx, "jac":xxx},
        #               objective_id:{"func":xxx, "jac":xxx},
        #               ... 
        #             }
        # Note that we still assume only one constraint
        print("> The following objectives are defined:\n")
        print(J,"\n")
        self.J = J

        # Define constraints
        # Format: C = { constraint_id:{"type":EQ , "func":xxx, "jac":xxx},
        #               constraint_id:{"type":INEQ , "func":xxx, "jac":xxx},
        #               ... 
        #             }
        # Note that we still assume only one constraint
        print("> The following constraints are defined:\n")
        print(C,"\n")
        self.C = C

        # Model parameters 
        self.opt_model_part = opt_model_part

        # Add toolbox for vertex morphing    
        max_nodes_affected = 10000 # Specification required by spatial (tree) search 
                                   # Defines maximum nodes that may be considered within the filter radius
        self.vm_utils = VertexMorphingUtilities(self.opt_model_part,config.filter_size,max_nodes_affected)

    # ********************************************************************************************
    def optimize(self):

        print("\n> ==============================================================================================================")
        print("> Starting optimization using the following algorithm: ",self.config.optimization_algorithm)
        print("> ==============================================================================================================\n")

        # Start timer and assign to object such that total time of opt may be measured at each step
        self.opt_start_time = time.time()

        # Initialize design output in GID Format
        self.gid_io.initialize_results(self.opt_model_part)

        # Call for for specified optimization algorithm
        if(self.config.optimization_algorithm == "steepest_descent"):
           self.start_steepest_descent()

        elif(self.config.optimization_algorithm == "method_of_feasible_directions"):
           self.start_feasible_directions()

        elif(self.config.optimization_algorithm == "augmented_lagrange"):
           self.start_augmented_lagrange()

        else:
            sys.exit("Specified optimization_algorithm not implemented!")

        # Finalize design output in GID formad
        self.gid_io.finalize_results()

        # Stop timer
        opt_end_time = time.time()

        print("\n> ==============================================================================================================")
        print("> Finished optimization in ",round(opt_end_time - self.opt_start_time,1)," s!")
        print("> ==============================================================================================================\n")

    # ********************************************************************************************
    def start_steepest_descent(self):

        # Flags to trigger proper function calls
        is_constrained_opt = False

        # Get Id of objective: Note that we assume in the following that only one objective is specified
        only_j_id = None
        for j_id in self.J:
            only_j_id = j_id

        # Initialize container to store optimization history
        # Format: some_func_val_history = { func_id: {opt_itr: func_value, opt_itr: func_value,...} }
        j_history = {} 
        j_history[only_j_id] = {}

        # Initialize file where design evolution is recorded
        with open(self.config.design_history_file, 'w') as csvfile:
            historyWriter = csv.writer(csvfile, delimiter=',',quotechar='|',quoting=csv.QUOTE_MINIMAL)
            row = []
            row.append("itr")
            row.append("\tj")
            row.append("\t\N{GREEK CAPITAL LETTER DELTA}j_absolut[%]")
            row.append("\t\N{GREEK CAPITAL LETTER DELTA}j_relative[%]")
            historyWriter.writerow(row)    
        
        # Define initial design (initial design corresponds to a zero shape update)
        # Note that we assume an incremental design variable in vertex morphing
        X = {}
        for node in self.opt_model_part.Nodes:
            X[node.Id] = [0.,0.,0.]

        # Start optimization loop
        for opt_itr in range(1,self.config.max_opt_iterations+1):

            # Some output
            print("\n>===============================================")
            print("> Starting optimization iteration ",opt_itr)
            print(">===============================================\n")

            # Start measuring time needed for current optimization step
            start_time = time.time()

            # Evaluate objective
            j = self.J[only_j_id]["func"](X,opt_itr)

            # Evaluate objective sensitivity
            dJdX = self.J[only_j_id]["jac"](X,opt_itr)

            # Store gradients on the nodes of the model_part
            self.store_grads_on_nodes( dJdX )

            # Compute unit surface normals at each node of current design
            self.vm_utils.compute_unit_surface_normals()

            print("node[2745].X = ",self.opt_model_part.Nodes[2745].X)

            # Project received gradients on unit surface normal at each node to obtain normal gradients
            dJdX_n = self.vm_utils.project_grad_on_unit_surface_normal( is_constrained_opt )

            # Compute filtered gradients (do backward mapping)
            self.vm_utils.filter_gradients( is_constrained_opt )

            # Compute search direction
            self.vm_utils.compute_search_direction_steepest_descent()

            # Compute design variable update (do one step in the optimization algorithm)
            self.vm_utils.update_design_variable( self.config.step_size_0 )

            # Compute shape update (do forward mapping)
            self.vm_utils.update_shape()

            # Store optimization results
            j_history[only_j_id][opt_itr] = j

            # Compute some measures to track changes in the objective function
            delta_j_absolut = 100* ( j_history[only_j_id][opt_itr]/j_history[only_j_id][1] - 1 )
            delta_j_relative = 0.0
            if(opt_itr>1):
                delta_j_relative = 100*( j_history[only_j_id][opt_itr]/j_history[only_j_id][opt_itr-1] - 1 )

            # Some console output for information
            if(opt_itr>1):
                print("\n> Current value of objective function = ",j)
                print("\n> Absolut change of objective function = ",delta_j_absolut)
                print("\n> Relative change of objective function = ",delta_j_relative)            

            # Write design history to file
            with open(self.config.design_history_file, 'a') as csvfile:
                historyWriter = csv.writer(csvfile, delimiter=',',quotechar='|',quoting=csv.QUOTE_MINIMAL)
                row = []
                row.append(str(opt_itr)+"\t")
                row.append("\t"+str("%.12f"%(j_history[only_j_id][opt_itr]))+"\t")
                row.append("\t"+str("%.2f"%(delta_j_absolut))+"\t")
                row.append("\t"+str("%.6f"%(delta_j_relative))+"\t")
                historyWriter.writerow(row)

            # Write design in GID format
            self.gid_io.write_results(opt_itr, self.opt_model_part, self.config.nodal_results, [])                

            # Check convergence
            if(opt_itr>1):

                # Check if maximum iterations were reached
                if(opt_itr==self.config.max_opt_iterations):
                    print("\n> Maximal iterations of supoptimization problem reached!")
                    break

                # Check for relative tolerance
                if(abs(delta_j_relative)<self.config.relative_tolerance_objective):
                    print("\n> Optimization subproblem converged within a relative objective tolerance of ",self.config.relative_tolerance_objective,".")
                    break

                # Check if value of objective increases
                if(j_history[only_j_id][opt_itr]>j_history[only_j_id][opt_itr-1]):
                    print("\n> Value of objective function increased!")
                    break

            # Update design
            X = self.get_design()

            # Take time needed for current optimization step
            end_time = time.time()
            print("\n> Time needed for current optimization step = ",round(end_time - start_time,1),"s")
            print("\n> Time needed for total optimization so far = ",round(end_time - self.opt_start_time,1),"s")

    # ********************************************************************************************
    def start_augmented_lagrange(self):

        # Get Id of objective: Note that we assume in the following that only one objective is specified
        only_j_id = None
        for id_i in self.J:
            only_j_id = id_i

        # Other variables needed
        j = None
        previous_l = None

        # Initialize container to store optimization history
        # Format: l,penalty_fac = { opt_itr: func_value, opt_itr: func_value,...}    
        # Format: j,c,lambda    = { func_id: {opt_itr: func_value, opt_itr: func_value,...},
        #                           func_id: {opt_itr: func_value, opt_itr: func_value,...},
        #                           ...,
        #                         }
        j_history = {} 
        j_history[only_j_id] = {}
        c_history = {}
        lambda_history = {} 
        penalty_fac_history = {}
        l_history = {}
        for c_id in self.C:
            c_history[c_id] = {}
            lambda_history[c_id] = {}

        # Initialize the optimization algorithm
        self.vm_utils.initialize_augmented_lagrange( self.C, self.config.penalty_fac_0, 
                                                     self.config.gamma, 
                                                     self.config.penalty_fac_max, 
                                                     self.config.lambda_0 )
        is_constrained_opt = True

        # Initialize file where design evolution is recorded
        with open(self.config.design_history_file, 'w') as csvfile:
            historyWriter = csv.writer(csvfile, delimiter=',',quotechar='|',quoting=csv.QUOTE_MINIMAL)
            row = []
            row.append("itr\t")
            row.append("\tsub_itr\t")
            row.append("\tl\t")
            row.append("\t\N{GREEK CAPITAL LETTER DELTA}l_relative[%]\t")
            row.append("\tj\t")
            row.append("\t\N{GREEK CAPITAL LETTER DELTA}j_absolut[%]\t")
            row.append("\tpenalty_fac\t")
            for c_id in self.C:
                row.append("\tc["+str(c_id)+"]: "+str(self.C[c_id]["type"])+"\t")
                row.append("\tlambda["+str(c_id)+"]\t")
            historyWriter.writerow(row)  

        # Define initial design (initial design corresponds to a zero shape update)
        # Note that we assume an incremental design variable in vertex morphing
        X = {}
        for node in self.opt_model_part.Nodes:
            X[node.Id] = [0.,0.,0.]   

        # Start primary optimization loop
        for opt_itr in range(1,self.config.max_opt_iterations+1):

            # Some output
            print("\n>===============================================")
            print("> Starting optimization iteration ",opt_itr)
            print(">===============================================\n")

            # Start measuring time needed for current optimization step
            start_time = time.time()

            # Data container to store the constraint values within the scope of the current iteration
            # Format: c = { 1: {"type": xxx , "value": xxx},
            #               2: {...},
            #               ...
            #             } 
            c = {}

            # Solve optimization subproblem
            for sub_opt_itr in range(1,self.config.max_sub_opt_iterations+1):

                # Some output
                print("\n>===============================================")
                print("> Starting suboptimization iteration ",sub_opt_itr)
                print(">===============================================\n")

                # Start measuring time needed for current suboptimization step
                subopt_start_time = time.time()

                # In the very first iteration we set opt_itr = 0 to allow for 
                # an identification of the initial design inside J and C
                if(opt_itr==1 and sub_opt_itr==1): opt_itr = 0

                # Evaluate objective 
                j = self.J[only_j_id]["func"](X,opt_itr)          

                # Evaluate objective sensitivity
                dJdX = self.J[only_j_id]["jac"](X,opt_itr)

                # Evaluate and store constraints and its sensitivities
                c.clear()
                for c_id in self.C:
                    c[c_id] = {}
                    c[c_id]["type"] = self.C[c_id]["type"]
                    c[c_id]["value"] = self.C[c_id]["func"](X,opt_itr)
                    dCdX = self.C[c_id]["jac"](X,opt_itr)

                # Evaluate Lagrange function
                l = self.vm_utils.get_value_of_augmented_lagrangian( j , c )

                # Store gradients on the nodes of the model_part
                self.store_grads_on_nodes( dJdX, dCdX )

                # Compute unit surface normals at each node of current design
                self.vm_utils.compute_unit_surface_normals()

                # Project received gradients on unit surface normal at each node to obtain normal gradients
                dJdX_n = self.vm_utils.project_grad_on_unit_surface_normal( is_constrained_opt )

                # Compute filtered gradients (do backward mapping)
                self.vm_utils.filter_gradients( is_constrained_opt )

                # Compute search direction
                self.vm_utils.compute_search_direction_augmented_lagrange( c )

                # Compute design variable update (do one step in the optimization algorithm)
                self.vm_utils.update_design_variable( self.config.step_size_0 )

                # Compute shape update (do forward mapping)
                self.vm_utils.update_shape()

                # Save initial design (before any suboptimization)
                if(opt_itr==0):

                    j_history[only_j_id][0] = j
                    l_history[0] = l
                    previous_l = l
                    penalty_fac_history[0] = self.vm_utils.get_penalty_fac()
                    for c_id in self.C:
                        c_history[c_id][0] = c[c_id]["value"]
                        lambda_history[c_id][0] = self.vm_utils.get_lambda(c_id)

                    # Reset opt_itr to correct value
                    opt_itr = 1

                # Compute some measures to track changes in the objective and Lagrange function
                delta_j_absolut = 100*(j/j_history[only_j_id][0] - 1)
                delta_l_relative = 100* (l/previous_l - 1)

                # Some console output for information
                if(sub_opt_itr>1):
                    print("\n> Current value of Lagrange function = ",l)
                    print("\n> Relative change of Lagrange function = ",delta_l_relative)

                # We write every major and every suboptimization iteration in design history
                with open(self.config.design_history_file, 'a') as csvfile:
                   historyWriter = csv.writer(csvfile, delimiter=',',quotechar='|',quoting=csv.QUOTE_MINIMAL)
                   row = []
                   row.append(str(opt_itr)+"\t")
                   row.append("\t"+str(sub_opt_itr)+"\t")
                   row.append("\t"+str("%.12f"%(l))+"\t")
                   row.append("\t"+str("%.6f"%(delta_l_relative))+"\t")
                   row.append("\t"+str("%.12f"%(j))+"\t")
                   row.append("\t"+str("%.2f"%(delta_j_absolut))+"\t")
                   row.append("\t"+str("%.2f"%(self.vm_utils.get_penalty_fac()))+"\t")
                   for c_id in self.C:
                       row.append("\t"+str("%.12f"%(c[c_id]["value"]))+"\t")
                       row.append("\t"+str("%.12f"%(self.vm_utils.get_lambda(c_id)))+"\t")
                   historyWriter.writerow(row)

                # Write design in GID format
                write_itr = opt_itr + 1/self.config.max_sub_opt_iterations*(sub_opt_itr-1)
                self.gid_io.write_results(write_itr, self.opt_model_part, self.config.nodal_results, [])

                # Check convergence (We ensure that at least 2 subiterations are done)
                if(sub_opt_itr>3):

                    # Check if maximum iterations were reached
                    if(sub_opt_itr==self.config.max_sub_opt_iterations): 
                        print("\n> Maximal iterations of supoptimization problem reached!")
                        break

                    # Check for relative tolerance
                    if(abs(delta_l_relative)<self.config.relative_tolerance_sub_opt): 
                        print("\n> Optimization subproblem converged within a relative objective tolerance of ",self.config.relative_tolerance_sub_opt,".")
                        break

                    # Check if value of lagrangian increases
                    if(l>previous_l):
                        print("\n> Value of Lagrange function increased!")
                        break

                # Update design
                X = self.get_design()   

                # Store j for convergence measures
                previous_l = l

                # Take time needed for current suboptimization step as well as for the overall opt so far
                subopt_end_time = time.time()
                print("\n> Time needed for current suboptimization step = ",round(subopt_end_time - subopt_start_time,1),"s")
                print("\n> Time needed for total optimization so far = ",round(subopt_end_time - self.opt_start_time,1),"s")

            # Log optimization results of the major optimization loop in the design history
            j_history[only_j_id][opt_itr] = j
            l_history[opt_itr] = l
            penalty_fac_history[opt_itr] = self.vm_utils.get_penalty_fac()
            for c_id in self.C:
                c_history[c_id][opt_itr] = c[c_id]["value"]
                lambda_history[c_id][opt_itr] = self.vm_utils.get_lambda(c_id)

            # Check Convergence (More convergence criterion for major optimization iteration to be implemented!)

            # Check if maximum iterations were reached
            if(opt_itr==self.config.max_opt_iterations):
                print("\n> Maximal iterations of optimization problem reached!")
                break
            
            # Update lagrange multipliers and penalty factor
            self.vm_utils.udpate_augmented_lagrange_parameters( c )  

            # Take time needed for current optimization step
            end_time = time.time()
            print("\n> Time needed for current optimization step = ",round(end_time - start_time,1),"s")

    # ********************************************************************************************
    def store_grads_on_nodes(self,dJdX,dCdX={}):

        # Read objective sensitivites
        eucledian_norm_obj_sens = 0.0
        for node_Id in dJdX:
            sens_i = Vector(3)
            sens_i[0] = dJdX[node_Id][0]
            sens_i[1] = dJdX[node_Id][1]
            sens_i[2] = dJdX[node_Id][2]           
            self.opt_model_part.Nodes[node_Id].SetSolutionStepValue(OBJECTIVE_SENSITIVITY,0,sens_i)
            eucledian_norm_obj_sens += sens_i[0] * sens_i[0] + sens_i[1] * sens_i[1] + sens_i[2] * sens_i[2]
        eucledian_norm_obj_sens = np.sqrt(eucledian_norm_obj_sens) 

        # When dCdX is defined also store constraint sensitivities (bool returns false if dictionary is empty)
        if(bool(dCdX)):
            eucledian_norm_cons_sens = 0.0
            for node_Id in dCdX:
                sens_i = Vector(3)
                sens_i[0] = dCdX[node_Id][0]
                sens_i[1] = dCdX[node_Id][1]
                sens_i[2] = dCdX[node_Id][2]           
                self.opt_model_part.Nodes[node_Id].SetSolutionStepValue(CONSTRAINT_SENSITIVITY,0,sens_i)
                eucledian_norm_cons_sens += sens_i[0] * sens_i[0] + sens_i[1] * sens_i[1] + sens_i[2] * sens_i[2]
            eucledian_norm_cons_sens = np.sqrt(eucledian_norm_cons_sens)                  

    # ********************************************************************************************
    def get_design(self):

        # Read and return the current design in the corresponding mode
        X = {}
        if(self.config.design_output_mode=="relative"):
            for node in self.opt_model_part.Nodes:
                X[node.Id] = node.GetSolutionStepValue(SHAPE_UPDATE)
        elif(self.config.design_output_mode=="total"):
            for node in self.opt_model_part.Nodes:
                X[node.Id] = node.GetSolutionStepValue(SHAPE_CHANGE_ABSOLUTE)
        elif(self.config.design_output_mode=="absolute"):
            for node in self.opt_model_part.Nodes:
                X[node.Id] = np.array([node.X,node.Y,node.Z])
        else:
            sys.exit("Wrong definition of design_output_mode!")

        return X

    # ********************************************************************************************

##################################################################################################

def CreateOptimizer(opt_model_part,config,J,G={}):

    # Create folder where all functions includig the optimizer may store their design history in
    os.system("rm -rf " + config.design_history_directory)
    os.system("mkdir -p " + config.design_history_directory)

    # Creat optimizer according to selected optimization method
    optimization_method = config.optimization_method

    if(optimization_method == "vertex_morphing"):
        optimizer = VertexMorphingMethod(opt_model_part,config,J,G)
        return optimizer

    else:
        sys.exit("Specified optimization_method not implemented")

##################################################################################################
