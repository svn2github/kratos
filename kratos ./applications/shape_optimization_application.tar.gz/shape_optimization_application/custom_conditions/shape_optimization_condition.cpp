//
//   Project Name:        Kratos
//   Last Modified by:    $Author:   Daniel Baumgärtner$
//   Date:                $Date:     January 2016$
//   Revision:            $Revision: 1.0 $
//
//

// System includes


// External includes


// Project includes
#include "custom_conditions/shape_optimization_condition.h"
#include "shape_optimization_application.h"


namespace Kratos
{

//***********************************************************************************
//***********************************************************************************
ShapeOptimizationCondition::ShapeOptimizationCondition(IndexType NewId, GeometryType::Pointer pGeometry)
    : Condition(NewId, pGeometry)
{
    //DO NOT ADD DOFS HERE!!!
}

//***********************************************************************************
//***********************************************************************************
ShapeOptimizationCondition::ShapeOptimizationCondition(IndexType NewId, GeometryType::Pointer pGeometry, PropertiesType::Pointer pProperties)
    : Condition(NewId, pGeometry, pProperties)
{
    //DO NOT ADD DOFS HERE!!!
}

//************************************************************************************
//************************************************************************************
ShapeOptimizationCondition::ShapeOptimizationCondition( ShapeOptimizationCondition const& rOther )
    : Condition(rOther)
{
}

//***********************************************************************************
//***********************************************************************************
Condition::Pointer ShapeOptimizationCondition::Create(IndexType NewId, NodesArrayType const& ThisNodes, PropertiesType::Pointer pProperties) const
{
    return Condition::Pointer(new ShapeOptimizationCondition(NewId, GetGeometry().Create(ThisNodes), pProperties));
}


//************************************CLONE*******************************************
//************************************************************************************
Condition::Pointer ShapeOptimizationCondition::Clone( IndexType NewId, NodesArrayType const& rThisNodes ) const
{
  return (this->Create( NewId, rThisNodes, pGetProperties() ) );
}


//***********************************************************************************
//***********************************************************************************
ShapeOptimizationCondition::~ShapeOptimizationCondition()
{
}


//************* COMPUTING  METHODS
//************************************************************************************
//************************************************************************************

//***********************************************************************************
//***********************************************************************************


int ShapeOptimizationCondition::Check( const ProcessInfo& rCurrentProcessInfo )
{
    return 0;
}

void ShapeOptimizationCondition::Calculate( const Variable< array_1d<double,3> >& rVariable, double& Output , ProcessInfo &rCurrentProcessInfo )
{
    // computes normalized surface normal for this condition
    if (rVariable == NORMALIZED_SURFACE_NORMAL)
    {
        Geometry<Node<3> >& pGeometry = this->GetGeometry();
        array_1d<double,3> normalized_normal(3,0.0);
        array_1d<double,3> v1;
        array_1d<double,3> v2;

        // For different geometries do different calculations
        if(pGeometry.size()==3) // triangle
        {
            v1[0] = pGeometry[1].X() - pGeometry[0].X();
            v1[1] = pGeometry[1].Y() - pGeometry[0].Y();
            v1[2] = pGeometry[1].Z() - pGeometry[0].Z();

            v2[0] = pGeometry[2].X() - pGeometry[0].X();
            v2[1] = pGeometry[2].Y() - pGeometry[0].Y();
            v2[2] = pGeometry[2].Z() - pGeometry[0].Z();

            // Compute area normal
            MathUtils<double>::CrossProduct(normalized_normal,v1,v2);
            normalized_normal *= 0.5;

            // Normalize by L2 Norm
            normalized_normal /= sqrt(normalized_normal[0]*normalized_normal[0] + normalized_normal[1]*normalized_normal[1] + normalized_normal[2]*normalized_normal[2]);

            // Assign result to variable
            noalias((this)->GetValue(NORMALIZED_SURFACE_NORMAL)) = normalized_normal;
        }
        else
        {
            KRATOS_THROW_ERROR(std::logic_error, "Given shape optimization condition geometry has not been implemented yet!","");
        }
    }
}

//***********************************************************************************
//***********************************************************************************

void ShapeOptimizationCondition::save( Serializer& rSerializer ) const
{
    KRATOS_SERIALIZE_SAVE_BASE_CLASS( rSerializer, Condition )
}

void ShapeOptimizationCondition::load( Serializer& rSerializer )
{
    KRATOS_SERIALIZE_LOAD_BASE_CLASS( rSerializer, Condition )
}


} // Namespace Kratos.
