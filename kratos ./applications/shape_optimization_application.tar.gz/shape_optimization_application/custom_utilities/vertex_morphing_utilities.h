//
//   Project Name:        Kratos
//   Last Modified by:    $Author:   Daniel Baumgärtner$
//   Date:                $Date:     January 2016$
//   Revision:            $Revision: 1.0 $
//
//

#ifndef VERTEX_MORPHING_UTILITIES_H
#define VERTEX_MORPHING_UTILITIES_H

// ============================================================
// System includes
// ============================================================

#include <iostream>
#include <string>
#include <algorithm>
#include <iomanip>      // for std::setprecision

// ============================================================
// External includes
// ============================================================

#include <boost/python.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/io.hpp>

// ============================================================
// Project includes
// ============================================================

// Note that in the following "../kratos/" was inserted to allow for proper code-highlighting and function following in qtCreator
// Might be necessary to exclude it again when committed

#include "../kratos/includes/define.h"
#include "../kratos/includes/define.h"
#include "../kratos/processes/process.h"
#include "../kratos/includes/node.h"
#include "../kratos/includes/element.h"
#include "../kratos/includes/model_part.h"
#include "../kratos/includes/kratos_flags.h"
#include "../kratos/spatial_containers/spatial_containers.h"
#include "../kratos/utilities/timer.h"
#include "../kratos/processes/node_erase_process.h"
#include "../kratos/utilities/binbased_fast_point_locator.h"
#include "../kratos/processes/find_conditions_neighbours_process.h"
#include "shape_optimization_application.h"


namespace Kratos
{

///@name Kratos Globals
///@{

///@}
///@name Type Definitions
///@{


///@}
///@name  Enum's
///@{

///@}
///@name  Functions
///@{

///@}
///@name Kratos Classes
///@{

/// Short class definition.
/** Detail class definition.

*/

class VertexMorphingUtilities
{
public:
    ///@name Type Definitions
    ///@{

    // ===================================================================================
    // Type definitions for better reading later
    // ===================================================================================

    typedef array_1d<double,3> array_3d;
    typedef Node < 3 > PointType;
    typedef Node < 3 > ::Pointer PointTypePointer;
    typedef std::vector<PointType::Pointer> PointVector;
    typedef std::vector<PointType::Pointer>::iterator PointIterator;
    typedef std::vector<double> DistanceVector;
    typedef std::vector<double>::iterator DistanceIterator;
    typedef ModelPart::ConditionsContainerType ConditionsArrayType;


    /// Pointer definition of VertexMorphingUtilities
    KRATOS_CLASS_POINTER_DEFINITION(VertexMorphingUtilities);

    ///@}
    ///@name Life Cycle
    ///@{

    /// Default constructor.
    VertexMorphingUtilities(ModelPart& model_part,
                            double filter_size,
                            const int max_nodes_affected)
        : mr_opt_model_part(model_part),
          m_filter_size(filter_size),
          m_number_of_design_variables(model_part.Nodes().size()),
          m_max_nodes_affected(max_nodes_affected)
    {
        // Set precision for output
        std::cout.precision(12);

        // For further geometrical operations we compute the neighbouring conditions for each node
        // This information may be used in the form "node_i.GetValue(NEIGHBOUR_CONDITIONS)"
        const int average_number_of_conditions = 10;
        const int average_number_of_nodes = 10;
        FindConditionsNeighboursProcess neighbour_finder = FindConditionsNeighboursProcess(mr_opt_model_part,
                                                                                           average_number_of_conditions,
                                                                                           average_number_of_nodes);
        neighbour_finder.Execute();
    }

    /// Destructor.
    virtual ~VertexMorphingUtilities()
    {
    }


    ///@}
    ///@name Operators
    ///@{


    ///@}
    ///@name Operations
    ///@{

    // ===================================================================================
    // General geometrical operations
    // ===================================================================================

    void compute_unit_surface_normals()
    {
        KRATOS_TRY;

        // We loop over all nodes of the design surface
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // In the following compute node normals of current node and store on respective variable

            // Find neighbour conditions (representing the neighbour elements on the optimization patch)
            WeakPointerVector<Condition>& neighbour_conditions = node_i.GetValue(NEIGHBOUR_CONDITIONS);

            // calculating the normals of each neighbouring condition and store it
            double optional_received_output = 0.0;
            for( unsigned int itr = 0 ; itr <  neighbour_conditions.size(); itr++ )
            {
                neighbour_conditions[itr].Calculate(NORMALIZED_SURFACE_NORMAL,optional_received_output,mr_opt_model_part.GetProcessInfo());
            }

            // adding the normals to the given node
            array_3d node_normal(3,0.0);
            for( unsigned int itr = 0 ; itr <  neighbour_conditions.size(); itr++ )
            {
                const array_1d<double,3>& condition_normal = neighbour_conditions[itr].GetValue(NORMALIZED_SURFACE_NORMAL);
                node_normal += condition_normal;
            }

            // Normalization of node normal
            double coeff = 1.0/(sqrt(node_normal[0] * node_normal[0] +  node_normal[1] * node_normal[1] +  node_normal[2] * node_normal[2]));
            noalias(node_i.FastGetSolutionStepValue(NORMALIZED_SURFACE_NORMAL)) = coeff * node_normal;
        }

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void project_grad_on_unit_surface_normal( bool is_constrained_opt )
    {
        KRATOS_TRY;

        // Initialize variables for normalization
        double J_norm = 0.0;
        double C_norm = 0.0;

        // We loop over all nodes and compute the part of the sensitivity which is in direction
        // to the surface normal
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // We compute dFdX_n = (dFdX \cdot n) * n
            array_3d node_sens = node_i.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY);
            array_3d node_normal = node_i.FastGetSolutionStepValue(NORMALIZED_SURFACE_NORMAL);
            array_3d normal_node_sens =  inner_prod(node_sens,node_normal) * node_normal;

            // Assign resulting sensitivity back to node
            noalias(node_i.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY)) = normal_node_sens;

            // Compute contribution to objective norm denominator
            J_norm += inner_prod(normal_node_sens,normal_node_sens);

            // Repeat for constraint
            if(is_constrained_opt)
            {
                // We compute dFdX_n = (dFdX \cdot n) * n
                node_sens = node_i.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY);
                node_normal = node_i.FastGetSolutionStepValue(NORMALIZED_SURFACE_NORMAL);
                normal_node_sens =  inner_prod(node_sens,node_normal) * node_normal;

                // Assign resulting sensitivity back to node
                noalias(node_i.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY)) = normal_node_sens;

                // Compute contribution to objective norm denominator
                C_norm += inner_prod(normal_node_sens,normal_node_sens);
            }
        }

        // Compute contribution to objective norm denominator
        J_norm = sqrt(J_norm);
        C_norm = sqrt(C_norm);

        // Normalize sensitivities
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            array_3d node_sens = node_i.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY);
            noalias(node_i.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY)) = node_sens/J_norm;

          // Repeat for constraint
            if(is_constrained_opt)
            {
                node_sens = node_i.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY);
                noalias(node_i.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY)) = node_sens/C_norm;
            }
        }

        KRATOS_CATCH("");
    }

    // ===================================================================================
    // For perfoming Vertex Morphing
    // ===================================================================================

    void filter_gradients( bool is_constraint_opt )
    {
        KRATOS_TRY;

        // Measure time of filtering
        boost::timer filtering_time;

        // Some output for information
        std::cout << "> Start backward filtering..." << std::endl;

        // Initialization of needed variables
        std::map<int,double> dJds; // Objective gradients
        std::map<int,double> dGds; // Constraint gradients


        // Creating an auxiliary list for the nodes to be searched on
        PointVector list_of_nodes;

        // Start constructing and computing the kdtree
        typedef Bucket< 3, PointType, PointVector, PointTypePointer, PointIterator, DistanceIterator > BucketType;
        typedef Tree< KDTreePartition<BucketType> > tree;

        // starting calculating time of construction of the kdtree
        boost::timer kdtree_construction;
        for (ModelPart::NodesContainerType::iterator node_it = mr_opt_model_part.NodesBegin(); node_it != mr_opt_model_part.NodesEnd(); ++node_it)
        {
            PointTypePointer pnode = *(node_it.base());

            // Putting the nodes of interest in an auxiliary list
            list_of_nodes.push_back(pnode);
        }
        std::cout << "> Construction time of KDTree: " << kdtree_construction.elapsed() << std::endl;

        // Arrays needed for spatial search
        PointVector nodes_affected(m_max_nodes_affected);
        DistanceVector resulting_squared_distances(m_max_nodes_affected);

        // compute the tree with the position of the nodes
        tree nodes_tree(list_of_nodes.begin(), list_of_nodes.end(), m_max_nodes_affected);

        // Loop over all design variables
        double max_dJds = 0.0;
        double max_dGds = 0.0;
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // perform spatial search for current node
            unsigned int number_of_nodes_affected;
            number_of_nodes_affected = nodes_tree.SearchInRadius(node_i, m_filter_size, nodes_affected.begin(),resulting_squared_distances.begin(), m_max_nodes_affected);

            // Store results to reuse later in the forward mapping
            m_listOf_nodesAffected[i_ID] = nodes_affected;
            m_number_of_nodes_affected[i_ID] = number_of_nodes_affected;

            // Compute weights
            std::map<int,array_3d> Ai;
            Ai = compute_weights(node_i,nodes_affected,number_of_nodes_affected);

            // Compute filtered gradients for objective function (Do backward mapping, filtering)
            double dJds_i = 0.0;
            for(unsigned int j = 0 ; j<number_of_nodes_affected ; j++)
            {
                int j_ID = nodes_affected[j]->Id();
                ModelPart::NodeType& node_j = mr_opt_model_part.Nodes()[j_ID];

                // Ask for the sensitiviteis
                array_3d node_sens = node_j.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY);

                // Compute dot-product
                dJds_i += Ai[j_ID][0] * node_sens[0] + Ai[j_ID][1] * node_sens[1] + Ai[j_ID][2] * node_sens[2];
            }
            dJds[i_ID] = dJds_i;

            // Store max value for later normalization
            if(fabs(dJds_i)>max_dJds)
                max_dJds = fabs(dJds_i);

            // If constrainted optimization, then also compute filtered gradients for the constraints (dGds)
            if(is_constraint_opt)
            {
                // Do backward mapping (filtering)
                double dGds_i = 0.0;
                for(unsigned int j = 0 ; j<number_of_nodes_affected ; j++)
                {
                    int j_ID = nodes_affected[j]->Id();
                    ModelPart::NodeType& node_j = mr_opt_model_part.Nodes()[j_ID];

                    // Ask for the sensitiviteis
                    array_3d node_sens = node_j.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY);

                    // Compute dot-product
                    dGds_i += Ai[j_ID][0] * node_sens[0] + Ai[j_ID][1] * node_sens[1] + Ai[j_ID][2] * node_sens[2];
                }
                dGds[i_ID] = dGds_i;

                // Store max value for later normalization
                if(fabs(dGds_i)>max_dGds)
                    max_dGds = fabs(dGds_i);
            }
        }

        // Filtered gradients are computed as dJds (dGds) normalized by its max-norm
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            m_filtered_dJdX[i_ID] = dJds[i_ID] / max_dJds;

            // If constraints are active, also normalize the filtered constraint gradients
            if(is_constraint_opt)
                m_filtered_dCdX[i_ID] = dGds[i_ID] / max_dGds;
        }

        std::cout << "> Finished backward filtering!" << std::endl;
        std::cout << "> Time needed for backward filtering: " << filtering_time.elapsed() << std::endl;

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    std::map<int,array_3d> compute_weights( ModelPart::NodeType& given_node,
                                            PointVector nodes_affected,
                                            unsigned int number_of_nodes_affected )
    {
        KRATOS_TRY;

        // Initializize variables
        std::map<int,array_3d> Ai;
        double summ_of_all_weights = 0.0;
        array_3d i_coord = given_node.Coordinates();

        // compute weights
        array_3d dist_vector(3,0.0);
        array_3d j_coord(3,0.0);;
        for(unsigned int j = 0 ; j<number_of_nodes_affected ; j++)
        {
            unsigned int j_ID = nodes_affected[j]->Id();
            j_coord[0] = nodes_affected[j]->X();
            j_coord[1] = nodes_affected[j]->Y();
            j_coord[2] = nodes_affected[j]->Z();

            dist_vector = i_coord - j_coord;
            double squared_scalar_distance = dist_vector[0] * dist_vector[0] + dist_vector[1] * dist_vector[1] + dist_vector[2] * dist_vector[2];

            // Computation of weight according specified weighting function (here it is the implementation of Carat)
            // Note that we did not compute the square root of the distances to save this expensive computation (it is not needed here)
            double Aij = exp(-squared_scalar_distance/(2*m_filter_size*m_filter_size/9.0));
            Ai[j_ID][0] = Aij;
            Ai[j_ID][1] = Aij;
            Ai[j_ID][2] = Aij;

            // Computed for necessary integration of weighting function (post-scaling)
            summ_of_all_weights += Aij;
        }

        // Here we perform the normalization by the sum of all weights & multiply by the node normal (nodal director)
        // In this way we implicitly preserve the in-plane mesh quality implicitely (pure Heuristic of Majid Hojjat)
        for(unsigned int j = 0 ; j<number_of_nodes_affected ; j++)
        {
            unsigned int j_ID = nodes_affected[j]->Id();
            Ai[j_ID] /= summ_of_all_weights;

            Ai[j_ID][0] *= given_node.FastGetSolutionStepValue(NORMALIZED_SURFACE_NORMAL)[0];
            Ai[j_ID][1] *= given_node.FastGetSolutionStepValue(NORMALIZED_SURFACE_NORMAL)[1];
            Ai[j_ID][2] *= given_node.FastGetSolutionStepValue(NORMALIZED_SURFACE_NORMAL)[2];
        }
        return Ai;

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void update_design_variable( double step_size )
    {
        KRATOS_TRY;

        // computation of update of design variable
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            m_design_variable_update[i_ID] = step_size * m_search_direction[i_ID];
        }

        KRATOS_CATCH("");
    }

    // ===================================================================================
    // General optimization operations
    // ===================================================================================

    void update_shape()
    {
        KRATOS_TRY;

        // Initialize variables
        std::map<int,array_3d> old_surface_nodes;
        std::map<int,array_3d> shape_update;

        // Store old surface nodes to reproduce later. Furthermore initialize the shape update
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // Store old coordinates
            array_3d old_node(3,0.0);
            old_node[0] = node_i.X();
            old_node[1] = node_i.Y();
            old_node[2] = node_i.Z();
            old_surface_nodes[i_ID] = old_node;

            // Initialize array
            array_3d zero_array(3,0.0);
            shape_update[i_ID] = zero_array;
        }
        // Perform the forward mapping

        // Loop over all design variables
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // Instead of performing spatial search again, we read the results obtained from "computeSearchDirection()"
            unsigned int number_of_nodes_affected = m_number_of_nodes_affected[i_ID];
            PointVector nodes_affected(number_of_nodes_affected);
            nodes_affected = m_listOf_nodesAffected[i_ID];

            // Compute weights
            std::map<int,array_3d> Ai;
            Ai = compute_weights(node_i,nodes_affected,number_of_nodes_affected);

            // Do forward mapping (filtering)
            for(unsigned int j = 0 ; j<number_of_nodes_affected ; j++)
            {
                unsigned int affectedNode_j_ID = nodes_affected[j]->Id();
                array_3d shape_update_affectedNode_j_ID(3,0.0);

                shape_update_affectedNode_j_ID[0] = Ai[affectedNode_j_ID][0] * m_design_variable_update[i_ID];
                shape_update_affectedNode_j_ID[1] = Ai[affectedNode_j_ID][1] * m_design_variable_update[i_ID];
                shape_update_affectedNode_j_ID[2] = Ai[affectedNode_j_ID][2] * m_design_variable_update[i_ID];

//                // Update coordinates in the mesh (note that this is only in accordance to carat, it is not yet known why
//                // this is done since by that the iteration sequence through the design variables plays an role)
//                mr_opt_model_part.Nodes()[affectedNode_j_ID].X() += shape_update_affectedNode_j_ID[0];
//                mr_opt_model_part.Nodes()[affectedNode_j_ID].Y() += shape_update_affectedNode_j_ID[1];
//                mr_opt_model_part.Nodes()[affectedNode_j_ID].Z() += shape_update_affectedNode_j_ID[2];

                // Store shape update contribution in global node list to update after all updates have been computed
                // Note that this is different as in carat. It is assumed that carat does a mistake here
                shape_update[affectedNode_j_ID][0] += shape_update_affectedNode_j_ID[0];
                shape_update[affectedNode_j_ID][1] += shape_update_affectedNode_j_ID[1];
                shape_update[affectedNode_j_ID][2] += shape_update_affectedNode_j_ID[2];
            }
        }

        // Store shape updates and update coordinates in the mesh AFTER all shape updates have been computed (as mentioned above, this is different as in carat)
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // Update coordinates
            node_i.X() += shape_update[i_ID][0];
            node_i.Y() += shape_update[i_ID][1];
            node_i.Z() += shape_update[i_ID][2];

            // Save shape update
            noalias(node_i.FastGetSolutionStepValue(SHAPE_UPDATE)) = shape_update[i_ID];
            noalias(node_i.FastGetSolutionStepValue(SHAPE_CHANGE_ABSOLUTE)) += shape_update[i_ID];
        }

        KRATOS_CATCH("");
    }

    // ===================================================================================
    // For running unconstrained descent methods
    // ===================================================================================

    void compute_search_direction_steepest_descent()
    {
        KRATOS_TRY;

        // Some output for information
        std::cout << "> No constraints given or active. The negative objective gradient is chosen as search direction..." << std::endl;

        // Clear search direction
        m_search_direction.clear();

        // search direction is negative of filtered gradient
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            m_search_direction[i_ID] = -1.0 * m_filtered_dJdX[i_ID];
        }

        KRATOS_CATCH("");
    }

    // ===================================================================================
    // For running method of feasible direction
    // ===================================================================================

    /**
     * Implements the method of feasible directions according to Vanderplaats' algorithm
     * page 173 in "Numerical Optimization Techniques in Engineering Design (Vanderplaats 1984)"
     */

    void compute_search_direction_feasible_direction()
    {
        KRATOS_TRY;

        using namespace boost::numeric::ublas;

        // Check if constraint is active:
        // If yes then perform feasible-usable step, if no, perform steepest descent step
        if(m_active_set.size()>0)
        {
            // Some output for information
            std::cout << ">> Constraint is active. A feasible usable search direction is computed..." << std::endl;

            // Clear search direction
            m_search_direction.clear();

            // First we prepare some working arrays and variables for a better implementation & reading
            const unsigned int num_design_var = m_number_of_design_variables;
            const unsigned int num_constraints = m_active_set.size();
            double theta = m_push_off_factors.begin()->second;
            const unsigned int N = num_constraints + 1;

            // Output for information
            std::cout << ">> theta = " << theta << std::endl;

            // Throw error message if number of constraint exceeds current limit
            if(num_constraints>1)
                KRATOS_THROW_ERROR(std::runtime_error, "The method of feasible directions is currently only implemented for one scalar unequality constraint", num_constraints);

            // Initialize A matrix
            matrix<double> A(N,num_design_var + 1);
            unsigned int j = 0;
            for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
            {
                unsigned int i_ID = node_itr->Id();
                A(0,j) = m_filtered_dCdX[i_ID];
                A(1,j) = m_filtered_dJdX[i_ID];
                j++;
            }
            A(0,num_design_var) = theta;
            A(1,num_design_var) = 1.0;

            // Initialize B matrix
            matrix<double> B(N,N);
            B = - prod(A,trans(A));

            // Initialize p vector
            vector<double> p(num_design_var+1,0.0);
            p(num_design_var) = 1;

            // Initialize c vector
            vector<double> c(N,0.0);
            c = - prod(A,p);

            // Initalize vector of lagrange multipliers
            vector<double> u(N,0.0);

            // Initialize I vector
            vector<unsigned int> I(num_design_var,0);

            // Start algorithm for solving subproblem

            // First outer loop
            while(1)
            {
                double a = 0.0;
                unsigned int k = 0;

                // First inner loop
                for(unsigned int i=1; i<N+1; i++)
                {
                    if(c(i-1)>=0.0)
                        continue;
                    else
                    {
                        double b = c(i-1)/B(i-1,i-1);
                        if(b<=a)
                            continue;
                        else
                        {
                            k = i;
                            a = b;
                        }
                    }
                }

                // Check if outer loop may be breaked
                if(k==0)
                    break;

                // Advance
                unsigned int j = I(k-1);
                if(j==0)
                    I(k-1) = k;
                else
                    I(k-1) = 0;
                double bb = B(k-1,k-1);

                // Second inner loop
                for(unsigned int j=1; j<N+1; j++)
                    B(k-1,j-1) = B(k-1,j-1) / bb;

                // Advance
                c(k-1) = a;
                B(k-1,k-1) = 1/bb;

                // Third inner loop
                for(unsigned int i=1; i<N+1; i++)
                {
                    if(i==k)
                        continue;
                    else
                    {
                        bb = B(i-1,k-1);
                        B(i-1,k-1) = 0.0;
                        for(unsigned int j=1; j<N+1; j++)
                            B(i-1,j-1) = B(i-1,j-1) - bb*B(k-1,j-1);
                        c(i-1) = c(i-1) - bb*a;
                    }
                }
            }

            // Second outer loop
            for(unsigned int i=1; i<N+1; i++)
            {
                u(i-1) = 0.0;
                unsigned int j = I(i-1);
                if(j>0)
                    u(i-1) = c(j-1);
                else
                    continue;
            }

            // Computation of s (note that the first num_design_var entries in y yield the search direction
            vector<double> y(num_design_var+1,0.0);
            y = p - prod(trans(A),u);
            double norm_search_direction = 0.0;
            unsigned int i = 0;
            for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
            {
                unsigned int i_ID = node_itr->Id();
                m_search_direction[i_ID] = y[i];
                norm_search_direction += m_search_direction[i_ID] * m_search_direction[i_ID];
                i++;
            }
            norm_search_direction = sqrt(norm_search_direction);

            // Output beta from the subproblem which indicates whether optimization converged (beta close to zero means, KKT are fullfilled)
            double beta = y[num_design_var];
            std::cout << ">> beta = " << beta << std::endl;

            // Normalize search direction
            for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
            {
                unsigned int i_ID = node_itr->Id();
                m_search_direction[i_ID] = m_search_direction[i_ID] / norm_search_direction;
            }

            // Check if search direction is feasible & usable <- This may be deleted later
            double dot_ab = 0.0;
            double dot_as = 0.0;
            double dot_bs = 0.0;
            double dot_ss = 0.0;
            double norm_a = 0.0;
            double norm_b = 0.0;
            for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
            {
                int i_ID = node_itr->Id();
                norm_a += m_filtered_dJdX[i_ID] * m_filtered_dJdX[i_ID];
                norm_b += m_filtered_dCdX[i_ID] * m_filtered_dCdX[i_ID];
                dot_ab += m_filtered_dJdX[i_ID] * m_filtered_dCdX[i_ID];
                dot_as += m_search_direction[i_ID] * m_filtered_dJdX[i_ID];
                dot_bs += m_search_direction[i_ID] * m_filtered_dCdX[i_ID];
                dot_ss += m_search_direction[i_ID] * m_search_direction[i_ID];
            }
            norm_a = sqrt(norm_a);
            norm_b = sqrt(norm_b);

            // For check if a and be are parallel
            double norm_product = norm_a * norm_b;
            // if a dot b = norm_a * norm_b --> parallel (0 Grad)
            // if a dot b = - norm_a * norm_b --> parallel (180 Grad)

            KRATOS_WATCH(norm_search_direction);
            KRATOS_WATCH(norm_product);
            KRATOS_WATCH(dot_ab);
            KRATOS_WATCH(dot_as);
            KRATOS_WATCH(dot_bs);
            KRATOS_WATCH(dot_ss);
        }
        else // if no constrains are active
            compute_search_direction_steepest_descent();

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void set_constraint_values( boost::python::dict py_current_constraints )
    {
        KRATOS_TRY;

        // Extract constraint values from python dict and sort in corresonding member C++ dict
        boost::python::list py_constraint_ids = py_current_constraints.keys();
        for (unsigned int i = 0; i < boost::python::len(py_constraint_ids); ++i)
        {
            boost::python::extract<int> cpp_constraint_id(py_constraint_ids[i]);
            boost::python::extract<double> extracted_constraint_value(py_current_constraints[py_constraint_ids[i]]);
            m_current_constraint_values[cpp_constraint_id] = extracted_constraint_value;
        }

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void identify_active_set( double epsilon )
    {
        KRATOS_TRY;

        // Clear active set
        m_active_set.clear();

        // Loop over all constraints and check which of them are active, put these in the active set
        typedef std::map<int,double>::iterator map_it_type;
        for(map_it_type itr = m_current_constraint_values.begin(); itr != m_current_constraint_values.end(); itr++)
        {
            double constraint_value = itr->second;
            int constraint_id = itr->first;

            if(constraint_value > epsilon)
                m_active_set[constraint_id] = constraint_value;
        }

        // If there are no active constraints, store current design and corresponding sensitivities which might be used later in the feasible direction algorithm to step back in the design history
        if(m_active_set.size()==0)
        {
            std::cout << ">> Updating last feasible design." << std::endl;

            for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
            {
                int i_ID = node_itr->Id();
                ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];
                array_3d node_coords;
                node_coords[0] = node_i.X();
                node_coords[1] = node_i.Y();
                node_coords[2] = node_i.Z();

                m_last_feasible_design[i_ID] = node_coords;
                m_last_feasible_design_obj_sensitivities[i_ID] = node_i.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY);
                m_last_feasible_design_cons_sensitivities[i_ID] = node_i.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY);
            }
        }

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void compute_push_off_factors( double theta_0 , double epsilon )
    {
        KRATOS_TRY;

        // Loop over the active set and compute corresponding push-off factors
        typedef std::map<int,double>::iterator map_it_type;
        for(map_it_type itr = m_active_set.begin(); itr != m_active_set.end(); itr++)
        {
            double g = itr->second;
            int g_id = itr->first;

            // Computation according to Vanderplaats 1984a
            m_push_off_factors[g_id] = (1.0-(g/epsilon)) * (1.0-(g/epsilon)) * theta_0;
        }

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void restore_last_feasible_design( )
    {
        KRATOS_TRY;

        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();
            ModelPart::NodeType& node_i = mr_opt_model_part.Nodes()[i_ID];

            // Read from stored values
            array_3d last_feasible_node_coords = m_last_feasible_design[i_ID];

            // Overwrite nodes coordinates according to last feasible design
            node_i.X() = last_feasible_node_coords[0];
            node_i.Y() = last_feasible_node_coords[1];
            node_i.Z() = last_feasible_node_coords[2];

            // Restore sensitivities from last feasible design to allow for a feasible direction computation
            node_i.FastGetSolutionStepValue(OBJECTIVE_SENSITIVITY) = m_last_feasible_design_obj_sensitivities[i_ID];
            node_i.FastGetSolutionStepValue(CONSTRAINT_SENSITIVITY) = m_last_feasible_design_cons_sensitivities[i_ID];
        }

        // Give some output for notification of the user
        std::cout << "> Last feasible design and corresponding objective and constraint sensitivities have been restored." << std::endl;

        KRATOS_CATCH("");
    }

    // ===================================================================================
    // For running augmented Lagrange method
    // ===================================================================================

    void initialize_augmented_lagrange( boost::python::dict py_C,
                                        double penalty_fac,
                                        double gamma,
                                        double penalty_fac_max,
                                        double lambda_0 )
    {
        KRATOS_TRY;

        // Store factors
        m_penalty_fac = penalty_fac;
        m_gamma = gamma;
        m_penalty_fac_max = penalty_fac_max;

        // Initialize a lagrange multiplier for each constraint
        boost::python::list py_C_ids = py_C.keys();
        for (unsigned int i = 0; i < boost::python::len(py_C_ids); ++i)
        {
            boost::python::extract<int> cpp_C_id(py_C_ids[i]);
            m_lambda[cpp_C_id] = lambda_0;
        }

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void compute_search_direction_augmented_lagrange(  boost::python::dict py_c )
    {
        KRATOS_TRY;

        // Some output for information
        std::cout << "> Search direction is computed as steepest descent direction of augmented Lagrange function..." << std::endl;

        // For the computation of the eucledian norm of the search direction (for normalization)
        double norm_search_direction = 0.0;

        // Compute search direction for each node
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
            int i_ID = node_itr->Id();

            // First term in the augmented lagrange function
            m_search_direction[i_ID] = m_filtered_dJdX[i_ID];

            // Loop over all constraints and add corresponding terms to Lagrange lagrange function
            boost::python::list py_c_ids = py_c.keys();
            for (unsigned int i = 0; i < boost::python::len(py_c_ids); ++i)
            {
                // Extract values to right type
                boost::python::extract<int> c_id(py_c_ids[i]);
                boost::python::extract<double> c_value(py_c[py_c_ids[i]]["value"]);
                boost::python::extract<std::string> c_type(py_c[py_c_ids[i]]["type"]);
                std::string c_type_string = c_type;

                // Different operations corresponding to equality and inequality constraints
                if(c_type_string == "EQ")
                {
                    // Contributions from constraints
                    m_search_direction[i_ID] += m_lambda[c_id] * m_filtered_dCdX[i_ID] + 2 * m_penalty_fac * c_value * m_filtered_dCdX[i_ID];
                }
                else if(c_type_string == "INEQ")
                {
                    KRATOS_THROW_ERROR(std::runtime_error, "Type of constraint not yet implemented!",c_type_string);
                }
                else
                    KRATOS_THROW_ERROR(std::runtime_error, "Wrong type of constraint. Choose either EQ or INEQ!",c_type_string);

                // Add contribution to the eucledian norm
                norm_search_direction += m_search_direction[i_ID] * m_search_direction[i_ID];
            }
        }

        // Compute eucledian norm
        norm_search_direction = sqrt(norm_search_direction);

        // Search direction is usually chosen as negative of gradient of augmented lagrange function
        // Furthermore we normalize the search direction
        for (ModelPart::NodeIterator node_itr = mr_opt_model_part.NodesBegin(); node_itr != mr_opt_model_part.NodesEnd(); ++node_itr)
        {
             int i_ID = node_itr->Id();
            m_search_direction[i_ID] = -1.0 * m_search_direction[i_ID] / norm_search_direction;
        }

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    void udpate_augmented_lagrange_parameters( boost::python::dict py_c )
    {
        KRATOS_TRY;

        // Loop over all constraints
        boost::python::list py_c_ids = py_c.keys();
        for (unsigned int i = 0; i < boost::python::len(py_c_ids); ++i)
        {
            // Extract values to right type
            boost::python::extract<int> c_id(py_c_ids[i]);
            boost::python::extract<double> c_value(py_c[py_c_ids[i]]["value"]);
            boost::python::extract<std::string> c_type(py_c[py_c_ids[i]]["type"]);
            std::string c_type_string = c_type;

            // Different operations corresponding to equality and inequality constraints
            if(c_type_string == "EQ")
            {
                // Update lambda corresponding to current constraint
                m_lambda[c_id] += 2 * m_penalty_fac * c_value;
            }
            else if(c_type_string == "INEQ")
            {
                KRATOS_THROW_ERROR(std::runtime_error, "Type of constraint not yet implemented!",c_type_string);
            }
            else
                KRATOS_THROW_ERROR(std::runtime_error, "Wrong type of constraint. Choose either EQ or INEQ!",c_type_string);
        }

        // Update penalty factor
        m_penalty_fac = m_gamma * m_penalty_fac;
        if(m_penalty_fac>m_penalty_fac_max)
            m_penalty_fac = m_penalty_fac_max;

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    double get_penalty_fac()
    {
        KRATOS_TRY;

        return m_penalty_fac;

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    double get_lambda(const int c_id)
    {
        KRATOS_TRY;

        return m_lambda[c_id];

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    double get_value_of_augmented_lagrangian( double j , boost::python::dict py_c )
    {
        KRATOS_TRY;

        // Compute value of augmented lagrange function and store on the following variable
        // First contribution is value of objective function
        double return_value = j;

        // Loop over all constraints
        boost::python::list py_c_ids = py_c.keys();
        for (unsigned int i = 0; i < boost::python::len(py_c_ids); ++i)
        {
            // Extract values to right type
            boost::python::extract<int> c_id(py_c_ids[i]);
            boost::python::extract<double> c_value(py_c[py_c_ids[i]]["value"]);
            boost::python::extract<std::string> c_type(py_c[py_c_ids[i]]["type"]);
            std::string c_type_string = c_type;

            // Different operations corresponding to equality and inequality constraints
            if(c_type_string == "EQ")
            {
                // Contributions from constraints
                return_value += m_lambda[c_id] * c_value + m_penalty_fac * c_value * c_value;
            }
            else if(c_type_string == "INEQ")
            {
                KRATOS_THROW_ERROR(std::runtime_error, "Type of constraint not yet implemented!",c_type_string);
            }
            else
                KRATOS_THROW_ERROR(std::runtime_error, "Wrong type of constraint. Choose either EQ or INEQ!",c_type_string);
        }

        return return_value;

        KRATOS_CATCH("");
    }

    // -----------------------------------------------------------------------------------

    ///@}
    ///@name Access
    ///@{


    ///@}
    ///@name Inquiry
    ///@{


    ///@}
    ///@name Input and output
    ///@{

    /// Turn back information as a string.
    virtual std::string Info() const
    {
        return "VertexMorphingUtilities";
    }

    /// Print information about this object.
    virtual void PrintInfo(std::ostream& rOStream) const
    {
        rOStream << "VertexMorphingUtilities";
    }

    /// Print object's data.
    virtual void PrintData(std::ostream& rOStream) const
    {
    }


    ///@}
    ///@name Friends
    ///@{


    ///@}

protected:
    ///@name Protected static Member Variables
    ///@{


    ///@}
    ///@name Protected member Variables
    ///@{


    ///@}
    ///@name Protected Operators
    ///@{


    ///@}
    ///@name Protected Operations
    ///@{


    ///@}
    ///@name Protected  Access
    ///@{


    ///@}
    ///@name Protected Inquiry
    ///@{


    ///@}
    ///@name Protected LifeCycle
    ///@{


    ///@}

private:
    ///@name Static Member Variables
    ///@{


    ///@}
    ///@name Member Variables
    ///@{

    // ===================================================================================
    // Initialized by class constructor
    // ===================================================================================

    ModelPart& mr_opt_model_part;
    const double m_filter_size;
    const unsigned int m_number_of_design_variables;
    const int m_max_nodes_affected;

    // ===================================================================================
    // General working arrays
    // ===================================================================================

    std::map<int,PointVector> m_listOf_nodesAffected;
    std::map<int,unsigned int> m_number_of_nodes_affected;
    std::map<int,double> m_design_variable_update;
    std::map<int,double> m_filtered_dJdX;
    std::map<int,double> m_filtered_dCdX;
    std::map<int,double> m_search_direction;

    // ===================================================================================
    // For running method of feasible direction
    // ===================================================================================

    std::map<int,array_3d> m_last_feasible_design;
    std::map<int,array_3d> m_last_feasible_design_obj_sensitivities;
    std::map<int,array_3d> m_last_feasible_design_cons_sensitivities;
    std::map<int,double> m_current_constraint_values; // [constraint_id,constraint_value]
    std::map<int,double> m_active_set;     // [constraint_id,constraint_value]
    std::map<int,double> m_push_off_factors; // [constraint_id,push_off_factor]

    // ===================================================================================
    // For running augmented Lagrange method
    // ===================================================================================

    double m_penalty_fac;
    double m_gamma;
    double m_penalty_fac_max;
    std::map<int,double> m_lambda;

    ///@}
    ///@name Private Operators
    ///@{


    ///@}
    ///@name Private Operations
    ///@{


    ///@}
    ///@name Private  Access
    ///@{


    ///@}
    ///@name Private Inquiry
    ///@{


    ///@}
    ///@name Un accessible methods
    ///@{

    /// Assignment operator.
//      VertexMorphingUtilities& operator=(VertexMorphingUtilities const& rOther);

    /// Copy constructor.
//      VertexMorphingUtilities(VertexMorphingUtilities const& rOther);


    ///@}

}; // Class VertexMorphingUtilities

///@}

///@name Type Definitions
///@{


///@}
///@name Input and output
///@{

///@}


}  // namespace Kratos.

#endif // VERTEX_MORPHING_UTILITIES_H
